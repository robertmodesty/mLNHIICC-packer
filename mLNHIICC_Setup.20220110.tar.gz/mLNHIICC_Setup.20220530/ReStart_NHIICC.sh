#!/bin/bash
sudo killall mLNHIICC;
#sudo killall nhiicc;
sleep 15;
sudo /usr/local/share/NHIICC/mLNHIICC & 
#sudo /usr/local/share/NHIICC/nhiicc --CertFile /usr/local/share/NHIICC/cert/NHIServerCert.crt --PrivateFileKey /usr/local/share/NHIICC/cert/NHIServerCert.key &
