#!/bin/bash
#
#
/usr/local/share/NHIICC/mLNHIICC &
#/usr/local/share/NHIICC/nhiicc --CertFile /usr/local/share/NHIICC/cert/NHIServerCert.crt --PrivateFileKey /usr/local/share/NHIICC/cert/NHIServerCert.key &
#

